﻿using Azure.Messaging.ServiceBus;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestASBConnection
{ //HEJ Klaus
    public class Program
    {
        // Main method
        private static async Task<int> Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Please provide the XID as an argument.");
                return 1; // Exit code 1 indicates a missing argument
            }
            // Arguments
            string xid = args[0];
            // Connection strings
            string sqlConnectionString = Properties.ApplicationsSetting.Default.SqlConnection; 
            string asbConnectionString = Properties.ApplicationsSetting.Default.ApiEndPoint ;
            string topicName = "items";
            // Json Batch size
            int batchSize = 2048;

            try
            {
                // Data Access Layer
                SqlAccess dataAccess = new SqlAccess(sqlConnectionString);
                DataTransformer transformer = new DataTransformer();
                AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);

                int offset = 0;
                List<UpdateMessage> updates;

                // Fetch a batch of updates
                UpdateObject newUpdate = new UpdateObject();
                newUpdate.dealer_id = xid;
                updates = await dataAccess.GetSparePartUpdatesAsync(xid, batchSize, offset);
                List<UpdateMessage> updates_batch = new List<UpdateMessage>();
                int count = 0;

                // Send the updates in batches
                foreach (UpdateMessage upm in updates)
                {
                    count++;
                    updates_batch.Add(upm);
                    if (count % batchSize == 0)
                    {
                        newUpdate.total = (count % batchSize == 0 ? batchSize : count % batchSize);
                        newUpdate.updates = updates_batch;
                        await SendNewUpdate(newUpdate);
                        updates_batch = new List<UpdateMessage>();
                    }
                }
                //Batch size 1000 entries
                newUpdate.total = (count % batchSize == 0 ? batchSize : count % batchSize);
                newUpdate.updates = updates_batch;
                if (newUpdate.total != 0)
                    await SendNewUpdate(newUpdate);


                Console.WriteLine("Data sent to the Azure Service Bus successfully.");
                return offset; // Return the total number of records sent as the exit code
            }

            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
                return -1; // Exit code -1 indicates an error
            }
            //Connects to the JMA Webparts API and Converts the update into Json.
            static async Task SendNewUpdate(object updates)
            {

                string asbConnectionString = Properties.ApplicationsSetting.Default.ApiEndPoint;
                string topicName = "items";
                DataTransformer transformer = new DataTransformer();
                AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);
                // Convert to JSON
                string jsonMessage = transformer.ConvertToJson(updates);
                int messageSize = transformer.GetMessageSizeInBytes(jsonMessage);
                //Console.Write(jsonMessage);
                Console.WriteLine($"Sending batch with size: {messageSize} bytes");
                // Send message
                await sender.SendMessageAsync(jsonMessage);
            }



        }
    }

}


#region MGE - Quick add on messages, Ended up not being needed
//// Method to send dealer update notification
//static async Task SendDealerUpdateNotification()
//{
//    string updateString = "Dealers har en update";
//    string asbConnectionString = "Endpoint=sb://jmatest1.servicebus.windows.net/;SharedAccessKeyName=JMATest;SharedAccessKey=OcSe3n3TLjsY+k/E+q71qoHZC1b68odlw+ASbJ5jC+g=;EntityPath=dealers";
//    string topicName = "dealers";
//    AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);
//    DataTransformer transformer = new DataTransformer();


//    // Convert to JSON
//    string jsonMessage = transformer.ConvertToJson(updateString);

//    // Send message
//    await sender.SendMessageAsync(jsonMessage);

//    Console.WriteLine("Dealer update notification sent successfully.");
//}

//// Method to send brand update notification
//static async Task SendBrandUpdateNotification()
//{
//    string updateString = "Brands har en update";
//    string asbConnectionString = "Endpoint=sb://jmatest1.servicebus.windows.net/;SharedAccessKeyName=TestAfBrandsMessage;SharedAccessKey=qYkXo4djQh+CIviegCWnwTpKDOY1Et2Yu+ASbCcXk9Y=;EntityPath=brands";
//    string topicName = "brands";
//    AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);
//    DataTransformer transformer = new DataTransformer();


//    // Convert to JSON
//    string jsonMessage = transformer.ConvertToJson(updateString);

//    // Send message
//    await sender.SendMessageAsync(jsonMessage);

//    Console.WriteLine("Brand update notification sent successfully.");
//}

#endregion
#region kgw
//private static async Task<int> Mainccc(string[] args)
//{
//    if (args.Length == 0)
//    {
//        Console.WriteLine("Please provide the XID as an argument.");
//        return 1; // Exit code 1 indicates a missing argument
//    }

//    string xid = args[0];
//    string sqlConnectionString = "Data Source=172.16.137.134\\SQL2022;Initial Catalog=JMA_base_2022;Persist Security Info=True;User ID=res_base;Password=89JMAdsm;TrustServerCertificate=True;";
//    string asbConnectionString = "Endpoint=sb://jmatest1.servicebus.windows.net/;SharedAccessKeyName=JMATest;SharedAccessKey=OcSe3n3TLjsY+k/E+q71qoHZC1b68odlw+ASbJ5jC+g=;EntityPath=dealers";
//    string topicName = "dealers";
//    int batchSize = 1000;


//    try
//    {
//        Data Access Layer
//       SqlAccess dataAccess = new SqlAccess(sqlConnectionString);
//        DataTransformer transformer = new DataTransformer();
//        AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);

//        int offset = 0;
//        List<UpdateMessage> updates;

//        Fetch a batch of updates
//       updates = await dataAccess.GetSparePartUpdatesAsync(xid, batchSize, offset);
//        List<UpdateMessage> updates_batch = new List<UpdateMessage>();
//        int count = 0;
//        foreach (UpdateMessage upm in updates)
//        {
//            count++;
//            updates_batch.Add(upm);
//            if (count % batchSize == 0)
//            {
//                await Sendxxxxx(updates_batch);
//                updates_batch = new List<UpdateMessage>();
//            }
//        }
//        await Sendxxxxx(updates_batch);


//        Console.WriteLine("Data sent to the Azure Service Bus successfully.");
//        return offset; // Return the total number of records sent as the exit code
//    }
//    catch (Exception ex)
//    {
//        Console.WriteLine("An error occurred: " + ex.Message);
//        return -1; // Exit code -1 indicates an error
//    }


//}
//static async Task Sendxxxxx(List<UpdateMessage> updates)
//{
//    string asbConnectionString = "Endpoint=sb://jmatest1.servicebus.windows.net/;SharedAccessKeyName=JMATest;SharedAccessKey=OcSe3n3TLjsY+k/E+q71qoHZC1b68odlw+ASbJ5jC+g=;EntityPath=dealers";
//    string topicName = "dealers";
//    DataTransformer transformer = new DataTransformer();
//    AzureServiceBusSender sender = new AzureServiceBusSender(asbConnectionString, topicName);
//    Convert to JSON
//    string jsonMessage = transformer.ConvertToJson(updates);
//    int messageSize = transformer.GetMessageSizeInBytes(updates);

//    Console.WriteLine($"Sending batch with size: {messageSize} bytes");
//    Send message
//    await sender.SendMessageAsync(jsonMessage);
//}

#endregion kgw
#region GammelVersion
//    private static async Task<int> Main(string[] args1)
//    {
//        if (args1.Length == 0)
//        {
//            Console.WriteLine("Please provide the XID as an argument.");
//            return 1; // Exit code 1 indicates a missing argument
//        }

//        string xid = args1[0];
//        string ASBConnectionString = "Endpoint=sb://jmatest1.servicebus.windows.net/;SharedAccessKeyName=JMATest;SharedAccessKey=OcSe3n3TLjsY+k/E+q71qoHZC1b68odlw+ASbJ5jC+g=;EntityPath=dealers";
//        string topicName = "dealers";
//        string directory = Directory.GetCurrentDirectory();
//        string filePath = Path.Combine(directory, "dummy_data.txt");


//        try
//        {

//            //Ensure the file exists before attempting to read it
//            if (!File.Exists(filePath))
//            {
//                Console.WriteLine($"File not found: {filePath}");
//                return -1; // Exit code -1 indicates an error
//            }

//            //Read the contents of the file
//            string fileContents = await File.ReadAllTextAsync(filePath);

//            //Send the file contents as a single message
//            await SendMessageAsync(ASBConnectionString, topicName, fileContents);

//            Console.WriteLine("File contents sent to the Azure Service Bus successfully.");
//            return 0; // Exit code 0 indicates success

//            //await SendMessageAsync(ASBConnectionString, topicName, "Test message from console app");

//            //List<string> sampleData = new List<string>
//            //{
//            //    "Item1: type1",
//            //    "Item2: type2",
//            //    "Item3: type3"
//            //};

//           // //Join the list into a single string with newline separators
//           // string batchMessage = string.Join(Environment.NewLine, sampleData);

//           // //Send the manually created message
//           //await SendMessageAsync(ASBConnectionString, topicName, batchMessage);

//           // Console.WriteLine("Manually created message sent successfully.");
//           // return 0; // Exit code 0 indicates success

//            //var batchObject = new { Data = sampleData };
//            //string batchMessage = JsonConvert.SerializeObject(batchObject, Formatting.Indented);

//            //// Send the manually created JSON batch as a message
//            //await SendMessageAsync(ASBConnectionString, topicName, batchMessage);

//            Console.WriteLine("Manually created JSON message sent successfully.");
//            return 0; // Exit code 0 indicates success
//            int sentCount = await GetSparePartUpdate(xid, ASBConnectionString, topicName);
//            return sentCount; // Return the number of sent records as the exit code
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine("An error occurred: " + ex.Message);
//            return -1; // Exit code -1 indicates an error
//        }
//    }

//    static async Task SendMessageAsync(string ASBConnectionString, string topicName, string message)
//    {
//        ServiceBusClient client = new ServiceBusClient(ASBConnectionString);
//        ServiceBusSender sender = client.CreateSender(topicName);

//        ServiceBusMessage busMessage = new ServiceBusMessage(message);
//        await sender.SendMessageAsync(busMessage);

//        await client.DisposeAsync();
//    }

//    static async Task<int> GetSparePartUpdate(string XID, string ABSConnectionString, string topicName)
//    {
//        string SQLConnectionString = "Data Source=172.16.137.134\\SQL2022;Initial Catalog=JMA_base_2022;Persist Security Info=True;User ID=res_base;Password=89JMAdsm;TrustServerCertificate=True;";

//        int sentCount = 0;
//        int batchSize = 1000; // Adjust batch size as needed


//        using (SqlConnection _sqlConnection = new SqlConnection(SQLConnectionString))
//        {
//            _sqlConnection.Open();

//            string commandText = $"exec [web].[ItemChanges] '{XID}'";
//            using (SqlCommand cmd = new SqlCommand(commandText, _sqlConnection))
//            {
//                using (SqlDataReader sqlReader = cmd.ExecuteReader())
//                {
//                    Console.WriteLine(sqlReader.Read());
//                    List<Task> tasks = new List<Task>();
//                    var data = new Dictionary<string, string>();

//                    while (await sqlReader.ReadAsync())
//                    {
//                        string item = sqlReader.GetString(0);
//                        string updateType = sqlReader.GetString(1);
//                        var updateMessage = new
//                        {
//                            Item = item,
//                            UpdateType = updateType
//                        };
//                        Console.WriteLine("updateMessage");

//                        data.Add(item, updateType);

//                    }
//                    Console.WriteLine(data);
//                    if (data.Count >= batchSize)
//                    {
//                        var batchObject = new { Data = data };
//                        string batchMessage = JsonConvert.SerializeObject(batchObject, Formatting.Indented);
//                        Console.WriteLine(batchMessage);
//                        Task t = SendMessageAsync(ABSConnectionString, topicName, batchMessage);
//                        tasks.Add(t);
//                        sentCount++;
//                        data.Clear(); // Clear the batch after sending
//                    }

//                    // Send any remaining messages in the batch
//                    if (data.Count > 0)
//                    {
//                        var batchObject = new { Data = data };
//                        string batchMessage = JsonConvert.SerializeObject(batchObject, Formatting.Indented);
//                        Task t = SendMessageAsync(ABSConnectionString, topicName, batchMessage);
//                        tasks.Add(t);
//                        sentCount++;
//                        data.Clear();
//                    }

//                    await Task.WhenAll(tasks);
//                }
//            }
//            return sentCount; // Return the count of sent messages
//        }
//    }
#endregion

